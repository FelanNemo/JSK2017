** >> Make sure you describe your PR in the README Change Log section! << **

This PR changes (delete as applicable)

* Documentation
* TypeScript Defs
* The public-facing API
* Nothing, it's a bug fix

Describe the changes below:

